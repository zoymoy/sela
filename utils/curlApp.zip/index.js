const axios = require('axios');

var handler = async function(event, context) {
  
    console.log('stageVariables');
    console.log(event.stageVariables.apiEndpoint);
    var apiLink = 'http://18.208.121.237:3000';
    if (event && event.stageVariables && event.stageVariables.apiEndpoint) {
        apiLink = event.stageVariables.apiEndpoint;
    }
  
    console.log(apiLink);
    console.log(event.path);
    var headers = event.headers;
    var pathNoVersion = event.path.replace(/(\/v[0-9]+)/g, '');
    var url = apiLink + pathNoVersion;
    console.log(url);
    return axios({
      method: event.httpMethod,
      url: url,
      headers: headers,
      params: event.queryStringParameters,
      data: event.body
    })
    .then(function(response) {
      console.log(response);
      const result = {
        isBase64Encoded: false,
        statusCode: response.status,
        headers: { headerName: "headerValue"},
        body: JSON.stringify(response.data)
    }
      return result;
    })
    .catch(function(ex) {
      console.log(ex);
      const response = {
        isBase64Encoded: false,
        statusCode: response.status,
        headers: { headerName: "headerValue"},
        body: JSON.stringify(ex.response.data)
      }
      return response;
    });
}

exports.handler = handler