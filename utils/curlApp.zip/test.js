const { handler } = require("./index");

var event = {
  path: '/lists/110/personal-fields',
  httpMethod: 'GET',
  headers:
   { Accept: 'application/json',
     'Accept-Encoding': 'gzip, deflate',
     Authorization: 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczpcL1wvY3AubmV3cmVzcG9uZGVyLmluZm8iLCJzdWIiOiJTRENhWVVqZDRmR2YiLCJpYXQiOjE1NzQwODA3MjQsImV4cCI6MTU3NDA4NzkyNH0.nmUnq_sABIk7Ne0CdUfc2mtJzbL-M2yUn3cah8qjVz4',
     'Cache-Control': 'no-cache',
     Host: '22pv05x7eb.execute-api.us-east-1.amazonaws.com',
     'Postman-Token': 'a891575e-195d-4ef3-b828-a516a1bc2299',
     'User-Agent': 'PostmanRuntime/7.18.0',
     'X-Amzn-Trace-Id': 'Root=1-5dd28b48-d19a45036fdb4b47e28ff300',
     'X-Forwarded-For': '49.37.12.18',
     'X-Forwarded-Port': '443',
     'X-Forwarded-Proto': 'https' },
  multiValueHeaders:
   { Accept: [ 'application/json' ],
     'Accept-Encoding': [ 'gzip, deflate' ],
     Authorization: [ 'Bearer  different token' ],
     'Cache-Control': [ 'no-cache' ],
     Host: [ '22pv05x7eb.execute-api.us-east-1.amazonaws.com' ],
     'Postman-Token': [ 'a891575e-195d-4ef3-b828-a516a1bc2299' ],
     'User-Agent': [ 'PostmanRuntime/7.18.0' ],
     'X-Amzn-Trace-Id': [ 'Root=1-5dd28b48-d19a45036fdb4b47e28ff300' ],
     'X-Forwarded-For': [ '49.37.12.18' ],
     'X-Forwarded-Port': [ '443' ],
     'X-Forwarded-Proto': [ 'https' ] },
  queryStringParameters: {},
  multiValueQueryStringParameters: { buy: [ 'lol' ], hello: [ 'params' ] },
  pathParameters: { listId: '5' },
  stageVariables: null,
  requestContext:
   { resourceId: 'dwtvf4',
     resourcePath: '/lists/{listId}',
     httpMethod: 'GET',
     extendedRequestId: 'DWqzUG_CIAMF3kA=',
     requestTime: '18/Nov/2019:12:15:04 +0000',
     path: '/dev/lists/5',
     accountId: '142700881312',
     protocol: 'HTTP/1.1',
     stage: 'dev',
     domainPrefix: '22pv05x7eb',
     requestTimeEpoch: 1574079304325,
     requestId: '190ab569-6114-49b8-976e-e1e7d1c94239',
     identity:
      { cognitoIdentityPoolId: null,
        accountId: null,
        cognitoIdentityId: null,
        caller: null,
        sourceIp: '49.37.12.18',
        principalOrgId: null,
        accessKey: null,
        cognitoAuthenticationType: null,
        cognitoAuthenticationProvider: null,
        userArn: null,
        userAgent: 'PostmanRuntime/7.18.0',
        user: null },
     domainName: '22pv05x7eb.execute-api.us-east-1.amazonaws.com',
     apiId: '22pv05x7eb' },
  body: null,
  isBase64Encoded: false
}

var data = handler(event, {});

console.log(data);